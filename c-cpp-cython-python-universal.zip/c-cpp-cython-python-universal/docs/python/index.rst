Welcome to @PROJECT_NAME@'s documentation!
==========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Modules
-------
.. automodule:: @PROJECT_NAME@
   :members: @Enter_your_members@

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`