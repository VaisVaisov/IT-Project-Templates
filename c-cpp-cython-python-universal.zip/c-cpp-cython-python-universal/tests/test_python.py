import sys
sys.path.append('../bin')

import wrapper
import numpy as np
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_hello_c():
    logger.info("Testing call_hello_c")
    assert wrapper.call_hello_c() == "Hello from C!"

def test_hello_cpp():
    logger.info("Testing call_hello_cpp")
    assert wrapper.call_hello_cpp() == "Hello from C++!"


# def test_array():
    # logger.info("Testing array multiplication")
    # arr = np.array([1, 2, 3], dtype=np.int32)
    # wrapper.multiply_array(arr, 2)
    # assert (arr == [2, 4, 6]).all()