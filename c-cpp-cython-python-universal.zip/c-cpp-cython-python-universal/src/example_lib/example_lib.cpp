#include "../include/example_lib/example_lib.hpp"
#include <iostream>

namespace example_lib {
    Calculator::Calculator() {
    }

    int Calculator::add(int a, int b) {
        return a + b;
    }

    int Calculator::multiply(int a, int b) {
        return a * b;
    }
}