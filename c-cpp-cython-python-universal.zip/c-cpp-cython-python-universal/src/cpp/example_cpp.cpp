#include "../include/cpp/example_cpp.hpp"
#include <iostream>

void hello_cpp() {
    std::cout << "Hello from C++!" << std::endl;
}