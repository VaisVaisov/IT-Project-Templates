#include "../include/c/example_c.h"
#include <stdio.h>

void hello_c() {
    printf("Hello from C!\n");
}