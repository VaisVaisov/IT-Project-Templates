#pragma once

namespace example_lib {
    class Calculator {
    public:
        Calculator();
        int add(int a, int b);
        int multiply(int a, int b);
    };
}