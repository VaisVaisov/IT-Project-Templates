#pragma once
void hello_c();