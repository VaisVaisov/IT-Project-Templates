from sys import path

path.append("../cython")

try:
    import wrapper
    print("Cython module loaded!")
    wrapper.call_hello_c()
    wrapper.call_hello_cpp()
    rresult = wrapper.use_calculator(3, 4)
    print(f"add: {result[0]}, mul: {result[1]}")
except ImportError as e:
    print("Cython module not built yet:", e)